count = localStorage.getItem("count");
document.querySelector(".cart-quantity").textContent = count;

var uni = JSON.parse(localStorage.getItem("uniq"));
console.log(uni);

for (let i = 0; i < uni.length; i++) {
  console.log(uni[1]);
  document.querySelector(".product-img").src = uni[1];
}

var deleteBts = document.querySelectorAll(".delete-quantity-link");
var cartItem = document.querySelectorAll(".cart-item-details-grid");
for (let i = 0; i < deleteBts.length; i++) {
  deleteBts[i].addEventListener("click", function () {
    cartItem[i].innerHTML = "";
  });
}
