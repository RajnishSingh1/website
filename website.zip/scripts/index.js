"use strict";
let count;
console.log(count);
var uniq;

const addedToCart = document.querySelectorAll(".added-to-cart");

const btsAddtocart = document.querySelectorAll(".add-to-cart-button");
const e = document.querySelectorAll(".MySelectOption");

const productImage = document.querySelectorAll(".product-image");
const productName = document.querySelectorAll(".product-name");
const productPrice = document.querySelectorAll(".product-price");

if (count === "undefined") {
  count = 0;
  document.querySelector(".cart-quantity").textContent = count;
} else {
  count = Number(JSON.parse(localStorage.getItem("count")));
  document.querySelector(".cart-quantity").textContent = count;
}
for (let i = 0; i < btsAddtocart.length; i++) {
  btsAddtocart[i].addEventListener("click", function () {
    addedToCart[i].style.visibility = "visible";
    setTimeout(function () {
      addedToCart[i].style.visibility = "hidden";
    }, 1000);

    const strUser = Number(e[i].options[e[i].selectedIndex].value);
    count += strUser;
    document.querySelector(".cart-quantity").textContent = count;
    localStorage.setItem("count", JSON.stringify(count));
    console.log(JSON.parse(localStorage.getItem("count")));
  });
}

var productDetails = [];
for (let i = 0; i < productImage.length; i++) {
  btsAddtocart[i].addEventListener("click", function () {
    if (productDetails.includes(productDetails[i])) {
      console.log("already");
    } else {
      productDetails.push(
        `[${productName[i].textContent},${productImage[i].src},${productPrice[i].textContent}]`
      );
    }
    uniq = [...new Set(productDetails)];
  });
}
document.querySelector(".cart-icon").addEventListener("click", function () {
  localStorage.setItem("uniq", JSON.stringify(uniq));
});
